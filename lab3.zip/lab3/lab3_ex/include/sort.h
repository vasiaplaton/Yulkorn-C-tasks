#pragma once
#include "deque.h"

void deque_quick_sort(deque* deq);