#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include "deque.h"
#include "deque_copy.h"
#include "io_file.h"
#include "sort.h"
#pragma once


void user_client();