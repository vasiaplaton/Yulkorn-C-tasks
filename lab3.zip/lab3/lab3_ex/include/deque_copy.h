#pragma once
#include"deque.h"
#include <stdlib.h> 
#include <string.h> 

void deque_copy(deque* original_deq, deque* copy_deq);