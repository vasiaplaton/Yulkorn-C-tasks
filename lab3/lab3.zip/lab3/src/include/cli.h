#pragma once

// Интерфейс командной строки
void user_client(void);
