#include "include/cli.h"

int main(void) {
    user_client();
    return 0;
}
